// ═══════════════════════════════════════════════════════════
// ECOCOLLECT — Firebase Configuration
// ───────────────────────────────────────────────────────────
// 1. Go to https://console.firebase.google.com
// 2. Create a new project called "ecocollect"
// 3. Click the </> (Web) icon to add a web app
// 4. Copy your config values below
// ═══════════════════════════════════════════════════════════

const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT_ID.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db   = firebase.firestore();

// ─── Firestore Security Rules (paste in Firebase Console → Firestore → Rules) ─
/*
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /pickupRequests/{requestId} {
      allow read, write: if request.auth != null
        && request.auth.uid == resource.data.userId;
      allow create: if request.auth != null;
    }
    match /collectors/{collectorId} {
      allow read: if request.auth != null;
    }
  }
}
*/

// ─── Seed a demo collector (run once in browser console) ──────────────────────
/*
async function seedCollector() {
  await db.collection("collectors").doc("collector_001").set({
    name: "Rajan Kumar",
    collectorId: "ECO-KA-0042",
    vehicle: "Tata Ace (KA-01-AB-1234)",
    rating: 4.8,
    onTimeRate: 96,
    area: "BTM Layout, Koramangala, HSR",
    experience: "3 years",
    totalCollections: 1247,
    phone: "+91 98765 43210",
    schedule: {
      Monday:    "9:00 AM – 1:00 PM",
      Wednesday: "9:00 AM – 1:00 PM",
      Friday:    "9:00 AM – 1:00 PM",
      Saturday:  "8:00 AM – 12:00 PM"
    }
  });
  console.log("Collector seeded!");
}
seedCollector();
*/
