# 🌿 EcoCollect

> A reward-based smart waste collection platform that lets users schedule doorstep pickups for recyclable materials and earn points for participating.

## 📖 About the Project

EcoCollect is a web-based platform built to make recycling more convenient and rewarding. Users can register, schedule a pickup for materials like plastic, paper, metal, glass, e-waste, and more, track their request status, and earn reward points once the pickup is completed — all through a simple dashboard.

**Live demo:** https://ecocollect-dae33.web.app

**Key features**
- 🔐 Secure sign-up/login with email verification (Firebase Authentication)
- 📅 Schedule pickups by material type, weight, date, and time slot
- 📊 Real-time dashboard — track request status (Pending → Collected)
- 🏆 Points & rewards system based on materials recycled
- 🚚 Collector profile view (assigned collector, ratings, schedule)
- 📱 Fully responsive design

**Tech stack**
| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, JavaScript |
| Backend / Auth | Firebase Authentication |
| Database | Firestore (Cloud NoSQL) |
| Hosting | Firebase Hosting |

---

## ⚙️ Setup Guide
> Follow these steps to run your own copy locally or deploy it.

---

## 📁 Files in this project

| File | Description |
|------|-------------|
| `index.html` | Landing page (public) |
| `auth.html` | Login & Registration with email verification |
| `dashboard.html` | Full dashboard (protected — login required) |
| `firebase-config.js` | Your Firebase credentials go here |
| `README.md` | This guide |

---

## 🚀 Setup Steps (15–20 minutes)

### Step 1 — Create a Firebase Project

1. Go to **https://console.firebase.google.com**
2. Click **"Add project"**
3. Name it `ecocollect`
4. Disable Google Analytics (not needed)
5. Click **"Create project"**

---

### Step 2 — Add a Web App

1. In your project dashboard, click the **`</>`** (Web) icon
2. Nickname: `ecocollect-web`
3. Click **"Register app"**
4. Copy the `firebaseConfig` object shown — it looks like:
   ```javascript
   const firebaseConfig = {
     apiKey: "AIzaSy...",
     authDomain: "ecocollect-xxxxx.firebaseapp.com",
     projectId: "ecocollect-xxxxx",
     storageBucket: "ecocollect-xxxxx.appspot.com",
     messagingSenderId: "1234567890",
     appId: "1:1234...:web:abc..."
   };
   ```
5. Paste these values into **`firebase-config.js`**

---

### Step 3 — Enable Email Authentication

1. In Firebase Console → **Authentication** → **Sign-in method**
2. Click **Email/Password**
3. Toggle **Enable** → Save

---

### Step 4 — Set Up Firestore Database

1. Firebase Console → **Firestore Database**
2. Click **"Create database"**
3. Choose **"Start in test mode"** (fine for exhibition)
4. Select region: **asia-south1 (Mumbai)** → Enable

---

### Step 5 — Set Firestore Security Rules

1. Firestore → **Rules** tab
2. Paste this:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /pickupRequests/{requestId} {
      allow read: if request.auth != null && request.auth.uid == resource.data.userId;
      allow create: if request.auth != null;
      allow update: if request.auth != null && request.auth.uid == resource.data.userId;
    }
    match /collectors/{collectorId} {
      allow read: if request.auth != null;
    }
  }
}
```

3. Click **Publish**

---

### Step 6 — Add Sample Collector Data

1. Open `index.html` in your browser
2. Open the browser DevTools Console (F12)
3. Navigate to `auth.html`, register an account, verify email
4. Navigate to `dashboard.html`
5. In the Console, paste and run:

```javascript
db.collection("collectors").doc("collector_001").set({
  name: "Rajan Kumar",
  collectorId: "ECO-KA-0042",
  vehicle: "Tata Ace (KA-01-AB-1234)",
  rating: 4.8,
  onTimeRate: 96,
  area: "BTM Layout, Koramangala, HSR",
  experience: "3 years",
  totalCollections: 1247,
  phone: "+91 98765 43210",
  schedule: {
    Monday:    "9:00 AM – 1:00 PM",
    Wednesday: "9:00 AM – 1:00 PM",
    Friday:    "9:00 AM – 1:00 PM",
    Saturday:  "8:00 AM – 12:00 PM"
  }
}).then(() => console.log("✅ Collector added!"));
```

---

### Step 7 — Run the Website

**Option A — Open directly (simplest for exhibition)**
- Just open `index.html` in Chrome. All 3 pages will work.

**Option B — Local server (recommended)**
```bash
# If you have Node.js:
npx serve .

# Or with Python:
python -m http.server 8080
```
Then open `http://localhost:8080`

**Option C — Deploy to internet (Firebase Hosting)**
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Set public directory to: . (current folder)
firebase deploy
```

---

## 🎯 Demo Flow for Exhibition

1. Open `index.html` — show the landing page
2. Click **"Get Started"** → Register a new account
3. Verify the email (check inbox)
4. Login → Dashboard loads with real user data
5. Go to **Schedule Pickup** → choose materials, set date/time → Submit
6. Go to **My Requests** → see the request with "Pending" status
7. Go to **My Collector** → show collector profile
8. Go to **Points & Rewards** → show rate card

To simulate a **"Collected"** status (for demo):
- Open Firebase Console → Firestore → pickupRequests
- Find your request document → change `status` to `collected` and `points` to `80`
- The dashboard updates live automatically!

---

## 🔧 Common Issues

| Problem | Solution |
|---------|----------|
| Blank page | Check browser console for errors; verify `firebase-config.js` has real values |
| "Permission denied" error | Check Firestore Rules are published correctly |
| Can't receive verification email | Check spam folder; use a real email address |
| Collector panel shows nothing | Run the seed script in Step 6 |
| Auth fails | Make sure Email/Password is enabled in Firebase Auth |

---

## 🌟 For Your Exhibition

✅ Works completely offline after first load (Firebase caches data)
✅ Real-time updates — changes in Firebase Console appear instantly on screen
✅ Mobile responsive — works on phones too
✅ Professional design — green eco theme with dark dashboard

**Judges will be impressed by:**
- Live data from a real cloud database
- Email verification flow
- Real-time request status updates
- Points system with rate card
- Collector profile with schedule

---

Built for college exhibition 🎓 | EcoCollect 2025
